import { useState } from 'react';
import { Plus, X, Search, Trash2 } from 'lucide-react';
import { ingredientsDatabase } from '../data/ingredients';
import { RecipeIngredient, UnitType, EggSize } from '../types/cookie';
import { CustomIngredientDialog } from './CustomIngredientDialog';

type MeasurementMode = 'metric' | 'imperial' | 'volumetric';

const EGG_WEIGHTS: Record<EggSize, number> = {
  small: 43,
  medium: 50,
  large: 57,
};

const UNIT_OPTIONS: Record<MeasurementMode, UnitType[]> = {
  metric: ['g', 'kg', 'mg'],
  imperial: ['oz', 'lb'],
  volumetric: ['cups', 'tbsp', 'tsp', 'ml', 'fl oz'],
};

const CATEGORIES = [
  { id: 'all',       name: 'All',       emoji: '🔍' },
  { id: 'flour',     name: 'Flours',    emoji: '🌾' },
  { id: 'sugar',     name: 'Sugars',    emoji: '🍬' },
  { id: 'fat',       name: 'Fats',      emoji: '🧈' },
  { id: 'egg',       name: 'Eggs',      emoji: '🥚' },
  { id: 'leavener',  name: 'Leaveners', emoji: '⬆️' },
  { id: 'liquid',    name: 'Liquids',   emoji: '💧' },
  { id: 'chocolate', name: 'Chocolate', emoji: '🍫' },
  { id: 'nut',       name: 'Nuts',      emoji: '🥜' },
  { id: 'other',     name: 'Other',     emoji: '➕' },
];

interface IngredientSelectorProps {
  ingredients: RecipeIngredient[];
  onIngredientsChange: (ingredients: RecipeIngredient[]) => void;
  measurementMode: MeasurementMode;
}

function AddIngredientModal({
  existing,
  onAdd,
  onClose,
}: {
  existing: RecipeIngredient[];
  onAdd: (ingredientId: string) => void;
  onClose: () => void;
}) {
  const [search, setSearch] = useState('');
  const [activeCat, setActiveCat] = useState('all');

  const existingIds = new Set(existing.map(e => e.ingredientId));

  const filtered = ingredientsDatabase.filter(ing => {
    if (existingIds.has(ing.id)) return false;
    const matchCat = activeCat === 'all' || ing.category === activeCat;
    const matchSearch = ing.name.toLowerCase().includes(search.toLowerCase());
    return matchCat && matchSearch;
  });

  return (
    <div className="fixed inset-0 z-50 bg-black/50 flex items-center justify-center p-4">
      <div className="bg-white rounded-2xl shadow-2xl w-full max-w-2xl max-h-[85vh] flex flex-col">

        {/* Header */}
        <div className="flex items-center justify-between p-4 border-b border-gray-200">
          <h3 className="text-lg font-bold text-gray-900">Add Ingredient</h3>
          <button onClick={onClose} className="text-gray-400 hover:text-gray-600 transition-colors">
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Search */}
        <div className="p-3 border-b border-gray-100">
          <div className="flex items-center gap-2 bg-gray-50 rounded-xl px-3 py-2">
            <Search className="w-4 h-4 text-gray-400 flex-shrink-0" />
            <input
              autoFocus
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Search ingredients..."
              className="flex-1 bg-transparent text-sm outline-none text-gray-700"
            />
            {search && (
              <button onClick={() => setSearch('')}>
                <X className="w-3.5 h-3.5 text-gray-400" />
              </button>
            )}
          </div>
        </div>

        {/* Category tabs */}
        <div className="flex gap-1.5 p-3 border-b border-gray-100 overflow-x-auto flex-shrink-0">
          {CATEGORIES.map((cat) => {
            const count = cat.id === 'all'
              ? ingredientsDatabase.filter(i => !existingIds.has(i.id)).length
              : ingredientsDatabase.filter(i => i.category === cat.id && !existingIds.has(i.id)).length;
            if (cat.id !== 'all' && count === 0) return null;
            return (
              <button
                key={cat.id}
                onClick={() => setActiveCat(cat.id)}
                className={`px-3 py-1.5 rounded-lg text-xs whitespace-nowrap font-medium transition-colors ${
                  activeCat === cat.id ? 'text-white' : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
                }`}
                style={activeCat === cat.id ? { background: 'linear-gradient(135deg, #c0392b, #e67e22)' } : {}}
              >
                {cat.emoji} {cat.name} ({count})
              </button>
            );
          })}
        </div>

        {/* Ingredient grid */}
        <div className="overflow-y-auto flex-1 p-3">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
            {filtered.map((ing) => (
              <button
                key={ing.id}
                onClick={() => { onAdd(ing.id); onClose(); }}
                className="text-left p-3 rounded-xl border border-gray-200 hover:border-red-300 hover:bg-red-50 transition-all group"
              >
                <div className="flex items-center gap-2 mb-1">
                  <span className="text-base">
                    {CATEGORIES.find(c => c.id === ing.category)?.emoji ?? '➕'}
                  </span>
                  <span className="text-sm font-medium text-gray-800 group-hover:text-red-700">
                    {ing.name}
                  </span>
                </div>
                <div className="text-xs text-gray-400">
                  {ing.calories} kcal · {ing.fat?.toFixed(1) ?? 0}g fat · {ing.sugar?.toFixed(1) ?? 0}g sugar
                </div>
              </button>
            ))}
          </div>
          {filtered.length === 0 && (
            <div className="text-center py-12 text-gray-400 text-sm">No ingredients found</div>
          )}
        </div>
      </div>
    </div>
  );
}

export function IngredientSelector({
  ingredients,
  onIngredientsChange,
  measurementMode,
}: IngredientSelectorProps) {
  const [showAddModal, setShowAddModal] = useState(false);
  const [showCustomDialog, setShowCustomDialog] = useState(false);

  const getDefaultUnit = (): UnitType => UNIT_OPTIONS[measurementMode][0];

  const addIngredient = (ingredientId: string) => {
    const ingredient = ingredientsDatabase.find(i => i.id === ingredientId);
    const isEgg = ingredient?.category === 'egg';
    const newIngredient: RecipeIngredient = {
      id: Date.now().toString(),
      ingredientId,
      amount: isEgg ? EGG_WEIGHTS.medium : 100,
      displayUnit: getDefaultUnit(),
      eggSize: isEgg ? 'medium' : undefined,
    };
    onIngredientsChange([...ingredients, newIngredient]);
  };

  const removeIngredient = (id: string) => {
    onIngredientsChange(ingredients.filter(ing => ing.id !== id));
  };

  const updateAmount = (id: string, amount: number) => {
    onIngredientsChange(ingredients.map(ing => ing.id === id ? { ...ing, amount } : ing));
  };

  const updateDisplayUnit = (id: string, unit: UnitType) => {
    onIngredientsChange(ingredients.map(ing => ing.id === id ? { ...ing, displayUnit: unit } : ing));
  };

  const updateEggSize = (id: string, eggSize: EggSize) => {
    onIngredientsChange(ingredients.map(ing =>
      ing.id === id ? { ...ing, eggSize, amount: EGG_WEIGHTS[eggSize] } : ing
    ));
  };

  const convertToDisplay = (grams: number, unit: UnitType, ingredient: any): string => {
    const density = ingredient?.density || 1.0;
    switch (unit) {
      case 'g':     return grams.toFixed(1);
      case 'kg':    return (grams / 1000).toFixed(3);
      case 'mg':    return (grams * 1000).toFixed(0);
      case 'oz':    return (grams * 0.035274).toFixed(2);
      case 'lb':    return (grams * 0.00220462).toFixed(3);
      case 'cups':  return (grams / (density * 236.588)).toFixed(2);
      case 'tbsp':  return (grams / (density * 14.7868)).toFixed(1);
      case 'tsp':   return (grams / (density * 4.92892)).toFixed(1);
      case 'ml':    return (grams / density).toFixed(1);
      case 'fl oz': return (grams / (density * 29.5735)).toFixed(2);
      default:      return grams.toFixed(1);
    }
  };

  const convertFromDisplay = (value: number, unit: UnitType, ingredient: any): number => {
    const density = ingredient?.density || 1.0;
    switch (unit) {
      case 'g':     return value;
      case 'kg':    return value * 1000;
      case 'mg':    return value / 1000;
      case 'oz':    return value / 0.035274;
      case 'lb':    return value / 0.00220462;
      case 'cups':  return value * density * 236.588;
      case 'tbsp':  return value * density * 14.7868;
      case 'tsp':   return value * density * 4.92892;
      case 'ml':    return value * density;
      case 'fl oz': return value * density * 29.5735;
      default:      return value;
    }
  };

  return (
    <div className="space-y-3">

      {/* Ingredient list */}
      {ingredients.length > 0 ? (
        <div>
          {ingredients.map((recipeIng) => {
            const ingredient = ingredientsDatabase.find(i => i.id === recipeIng.ingredientId);
            const displayName = ingredient?.name || recipeIng.customName || 'Custom Ingredient';
            const category = ingredient?.category || 'custom';
            const catEmoji = CATEGORIES.find(c => c.id === category)?.emoji ?? '➕';
            const currentUnit = recipeIng.displayUnit || getDefaultUnit();
            const availableUnits = UNIT_OPTIONS[measurementMode];
            const isEgg = ingredient?.category === 'egg';
            const currentEggSize = recipeIng.eggSize || 'medium';

            return (
              <div key={recipeIng.id} className="flex items-center gap-2 py-2 border-b border-gray-100 last:border-0">
                <span className="text-base flex-shrink-0">{catEmoji}</span>
                <div className="flex-1 min-w-0">
                  <div className="text-sm font-medium text-gray-800 truncate">{displayName}</div>
                  <div className="text-xs text-gray-400 capitalize">{category}</div>
                </div>
                <div className="flex items-center gap-1 flex-shrink-0">
                  {isEgg && (
                    <select
                      value={currentEggSize}
                      onChange={(e) => updateEggSize(recipeIng.id, e.target.value as EggSize)}
                      className="text-xs border border-gray-200 rounded-lg px-1.5 py-1 bg-white focus:outline-none focus:ring-2 focus:ring-red-300 cursor-pointer"
                    >
                      <option value="small">Small</option>
                      <option value="medium">Medium</option>
                      <option value="large">Large</option>
                    </select>
                  )}
                  <input
                    type="number"
                    value={convertToDisplay(recipeIng.amount, currentUnit, ingredient)}
                    onChange={(e) => {
                      const value = parseFloat(e.target.value) || 0;
                      updateAmount(recipeIng.id, convertFromDisplay(value, currentUnit, ingredient));
                    }}
                    className="w-16 text-right text-sm border border-gray-200 rounded-lg px-2 py-1 focus:outline-none focus:ring-2 focus:ring-red-300"
                    step="0.1"
                    min="0"
                  />
                  <select
                    value={currentUnit}
                    onChange={(e) => updateDisplayUnit(recipeIng.id, e.target.value as UnitType)}
                    className="text-xs border border-gray-200 rounded-lg px-1.5 py-1 bg-white focus:outline-none focus:ring-2 focus:ring-red-300 cursor-pointer"
                  >
                    {availableUnits.map(unit => (
                      <option key={unit} value={unit}>{unit}</option>
                    ))}
                  </select>
                  <button
                    onClick={() => removeIngredient(recipeIng.id)}
                    className="text-gray-300 hover:text-red-500 transition-colors ml-1"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      ) : (
        <div className="text-center py-6 text-gray-400 text-sm">
          No ingredients yet. Click Add Ingredient to start.
        </div>
      )}

      {/* Add buttons */}
      <div className="flex gap-2 pt-1">
        <button
          onClick={() => setShowAddModal(true)}
          className="flex items-center gap-1.5 text-white text-sm font-medium px-4 py-2 rounded-xl transition-opacity hover:opacity-90"
          style={{ background: 'linear-gradient(135deg, #c0392b, #e67e22)' }}
        >
          <Plus className="w-4 h-4" />
          Add Ingredient
        </button>
        <button
          onClick={() => setShowCustomDialog(true)}
          className="flex items-center gap-1.5 bg-gray-100 hover:bg-gray-200 text-gray-700 text-sm font-medium px-4 py-2 rounded-xl transition-colors"
        >
          <Plus className="w-4 h-4" />
          Custom
        </button>
      </div>

      {showAddModal && (
        <AddIngredientModal
          existing={ingredients}
          onAdd={(id) => { addIngredient(id); }}
          onClose={() => setShowAddModal(false)}
        />
      )}

      {showCustomDialog && (
        <CustomIngredientDialog
          onClose={() => setShowCustomDialog(false)}
          onAdd={(customIngredient) => {
            onIngredientsChange([...ingredients, customIngredient]);
            setShowCustomDialog(false);
          }}
        />
      )}
    </div>
  );
}
